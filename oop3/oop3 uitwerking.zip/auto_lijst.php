<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Autolijst</title>
    <?php include('auto.php') ?>
</head>
<body>
    <?php
        $auto1 = new auto("Ferrari", "rood", 100000, 200000);
        $auto2 = new auto("Volkswagen", "groen", 30000, 40000);
        $auto3 = new auto("Mazda", "geel", 15000, 25000);
        $auto4 = new auto("Toyota", "wit", 35000, 50000);
    ?>
    <table>
        <tr><td><?= $auto1->get_merk() ?></td><td><?= $auto1->get_kleur() ?></td><td><?= $auto1->winst() ?></td></tr>
        <tr><td><?= $auto2->get_merk() ?></td><td><?= $auto2->get_kleur() ?></td><td><?= $auto2->winst() ?></td></tr>
        <tr><td><?= $auto3->get_merk() ?></td><td><?= $auto3->get_kleur() ?></td><td><?= $auto3->winst() ?></td></tr>
        <tr><td><?= $auto4->get_merk() ?></td><td><?= $auto4->get_kleur() ?></td><td><?= $auto4->winst() ?></td></tr>
    </table>
</body>
</html>