<?php
class auto{
    var $merk;
    var $kleur;
    private $kostprijs;
    public $verkoopprijs;

    function __construct($auto_merk, $auto_kleur, $auto_kostprijs, $auto_verkoopprijs){
        $this->merk = $auto_merk;
        $this->kleur = $auto_kleur;
        $this->kostprijs = $auto_kostprijs;
        $this->verkoopprijs = $auto_verkoopprijs;
    }

    function set_merk($nieuw_merk){
        $this->merk = $nieuw_merk;
    }

    function get_merk(){
        return $this->merk;
    }

    function set_kleur($nieuwe_kleur){
        $this->kleur = $nieuwe_kleur;
    }

    function get_kleur(){
        return $this->kleur;
    }

    function set_kostprijs($nieuwe_kostprijs){
        $this->kostprijs = $nieuwe_kostprijs;
    }


    function set_verkoopprijs($nieuwe_verkoopprijs){
        $this->verkoopprijs = $nieuwe_verkoopprijs;
    }

    
    function get_verkoopprijs(){
        return $this->verkoopprijs;
    }

    function winst(){
        return $this->verkoopprijs - $this->kostprijs;
    }
}
?>