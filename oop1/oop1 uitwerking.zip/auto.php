<?php
class auto{
    var $merk;
    var $kleur;
    function set_merk($nieuw_merk){
        $this->merk = $nieuw_merk;
    }
    function get_merk(){
        return $this->merk;
    }
    function set_kleur($nieuwe_kleur){
        $this->kleur = $nieuwe_kleur;
    }
    function get_kleur(){
        return $this->kleur;
    }
}
?>