<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Autolijst</title>
    <?php include('auto.php') ?>
</head>
<body>
    <?php
        $auto1 = new auto();
        $auto2 = new auto();
        $auto3 = new auto();
        $auto4 = new auto();
        $auto1->set_merk("Ferrari");
        $auto2->set_merk("Volkswagen");
        $auto3->set_merk("Mazda");
        $auto4->set_merk("Toyota");
        $auto1->set_kleur("rood");
        $auto2->set_kleur("groen");
        $auto3->set_kleur("geel");
        $auto4->set_kleur("wit");
    ?>
    <table>
        <tr><td><?= $auto1->get_merk() ?></td><td><?= $auto1->get_kleur() ?></td></tr>
        <tr><td><?= $auto2->get_merk() ?></td><td><?= $auto2->get_kleur() ?></td></tr>
        <tr><td><?= $auto3->get_merk() ?></td><td><?= $auto3->get_kleur() ?></td></tr>
        <tr><td><?= $auto4->get_merk() ?></td><td><?= $auto4->get_kleur() ?></td></tr>
    </table>
</body>
</html>