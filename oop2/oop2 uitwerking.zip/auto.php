<?php
class auto{
    var $merk;
    var $kleur;

    function __construct($auto_merk, $auto_kleur){
        $this->merk = $auto_merk;
        $this->kleur = $auto_kleur;
    }

    function set_merk($nieuw_merk){
        $this->merk = $nieuw_merk;
    }

    function get_merk(){
        return $this->merk;
    }

    function set_kleur($nieuwe_kleur){
        $this->kleur = $nieuwe_kleur;
    }

    function get_kleur(){
        return $this->kleur;
    }
}
?>